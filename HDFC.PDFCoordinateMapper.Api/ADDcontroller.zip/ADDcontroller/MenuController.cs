﻿using DAL;
using DAL.CommonClasses;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Http;
using System.Web.Http.Cors;
using Webapi.Models;

namespace Webapi.Controllers
{
    //[EnableCors(origins: "http://localhost:58929", headers: "*", methods: "*", SupportsCredentials = true, PreflightMaxAge = 86400)]
    //[Authorize]
    [UseSSL]
    public class MenuController : ApiController
    {
        CommonFunction cf = new CommonFunction();

        // [Route("api/{Menu}/{getmenu}")]
        // [EnableCors(origins: "*", headers: "*", methods: "*")]
        [HttpPost]
        public IHttpActionResult getmenu([FromBody]JObject json)
        {
            try
            {
                // USER VALIDATION START 12 09 2024
                // Get Authorization header
                var authorizationHeader = Request.Headers.Authorization?.ToString();                //Added  by Ketan Jadhav Dated 12-Sept-2024
                if (cf.OnAuthorizationCheck(authorizationHeader) == true)
                {
                    
                }
                else
                {
                    return null;
                }
                Menu request = JsonConvert.DeserializeObject<Menu>(json.ToString());
                string roleid = fnGetDecryptedString(request.roleid);

                string moduleid = fnGetDecryptedString(request.Moduleid);

                Menus objmenu = new Menus();
                var menulist = objmenu.GetMenuList(roleid, moduleid);
                if (menulist == null)
                {
                    return NotFound();
                }
                return Ok(menulist);
            }
            catch (Exception ex)
            {
                return Ok(ex.ToString());
            }
           // return "test123";
        }



        public string fnGetDecryptedString(string str)
        {
            if (str == null)
            {
                return str;
            }
            else
            {
                var keybytes = Encoding.UTF8.GetBytes("8080808080808080");
                var iv = Encoding.UTF8.GetBytes("8080808080808080");

                byte[] str1 = Convert.FromBase64String(str);
                str = AESEncrytDecry.Decrypt(str1, keybytes, iv);
                return str;
            }

        }


    }
}
