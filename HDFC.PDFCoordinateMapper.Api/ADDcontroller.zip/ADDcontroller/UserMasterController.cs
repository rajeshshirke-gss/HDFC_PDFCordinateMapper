﻿
using BAL;
using DAL;
using DAL.CommonClasses;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Web.Http;
using System.Web.Http.Cors;
using Webapi.Models;

namespace Webapi.Controllers
{
    //[EnableCors(origins: "http://localhost:58929", headers: "*", methods: "*", SupportsCredentials = true, PreflightMaxAge = 86400)]
  //  [Authorize(Roles = "User Admin,Super Admin")]
   // [UseSSL]
    public class UserMasterController : ApiController
    {
        DataSet dsoutput;
        DataTable dtinput;
        CommonFunction cf = new CommonFunction();
        Masters objmasters = new Masters();
        [Route("api/UserMaster/SaveUserMaster")]
        [HttpPost]
        
        public DataSet SaveUserMaster(User_Master userMaster)
         {
            DataSet ds = new DataSet();
           // userMaster.Password = Encrypt(GeneratePassword());
            UserMaster objRole = new UserMaster();
            try
            {
                //if (fnGetDecryptedString(userMaster.UserRole).ToUpper().Trim() == "NILESH.SAIL" || fnGetDecryptedString(userMaster.UserRole).ToUpper().Trim() == "PCM.ALERTS")
                //{
                    ds = objRole.SaveRecord(userMaster);
                //}
                //else
                //{
                //    DataTable dt = new DataTable();
                //    dt.Columns.Add("status");
                //    dt.Columns.Add("msg");
                //    //dt.Columns["Token"].DefaultValue = tokenandexpire[0];
                //    DataRow row = dt.NewRow();
                //    row["status"] = "-1";
                //    dt.Rows.Add(row);
                //    DataRow row1 = dt.NewRow();
                //    row["msg"] = "User is not Authorized";
                //    dt.Rows.Add(row1);
                //    dt.TableName = "table";
                //    //if (!ds.Tables.Contains(dt.TableName))
                //    ds.Tables.Add(dt);
                //    // response = "User is not Authorized";
                //}

            }
            catch (Exception ex)
            {
         

            }
            return ds;
        }




        private string Encrypt(string password)
        {
            string EncryptionKey = Convert.ToString(ConfigurationManager.AppSettings["EncryptionKey"]);
            byte[] clearBytes = Encoding.Unicode.GetBytes(password);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(clearBytes, 0, clearBytes.Length);
                        cs.Close();
                    }
                    password = Convert.ToBase64String(ms.ToArray());
                }
            }
            return password;
        }


        public string EncodePassword(string password)
        {
            try
            {
                byte[] encData_byte = new byte[password.Length];
                encData_byte = System.Text.Encoding.UTF8.GetBytes(password);
                string encodedData = Convert.ToBase64String(encData_byte);
                return encodedData;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in base64Encode" + ex.Message);
            }
        } //this function Convert to Decord your Password
        public string DecodeFrom64(string encodedData)
        {
            System.Text.UTF8Encoding encoder = new System.Text.UTF8Encoding();
            System.Text.Decoder utf8Decode = encoder.GetDecoder();
            byte[] todecode_byte = Convert.FromBase64String(encodedData);
            int charCount = utf8Decode.GetCharCount(todecode_byte, 0, todecode_byte.Length);
            char[] decoded_char = new char[charCount];
            utf8Decode.GetChars(todecode_byte, 0, todecode_byte.Length, decoded_char, 0);
            string result = new String(decoded_char);
            return result;
        }

        public string GeneratePassword()
        {
            string _allowedChars = "abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ0123456789-";
            Random randNum = new Random((int)DateTime.Now.Ticks);
            char[] chars = new char[8];

            for (int i = 0; i < 8; i++)
            {
                chars[i] = _allowedChars[randNum.Next(_allowedChars.Length)];
            }
            return new string(chars);
        }

        [Route("api/UserMaster/GetUserMaster")]
        public DataSet GetUserMaster()
        {
            User_Master userMaster = new User_Master();
            userMaster.Flag = "S";
            DataSet ds = new DataSet();
            UserMaster objRole = new UserMaster();
            try
            {
                ds = objRole.GetRecord(userMaster);
            }
            catch (Exception ex)
            {


            }
            return ds;
        }

        [Route("api/UserMaster/Delete_UserMaster")]
        [HttpPost]
        public DataSet Delete_UserMaster(User_Master user)
        {
            user.Flag = "D";
            DataSet ds = new DataSet();
            UserMaster objRole = new UserMaster();
            try
            {

                //if (fnGetDecryptedString(user.UserRole).ToUpper().Trim() == "NILESH.SAIL" || fnGetDecryptedString(user.UserRole).ToUpper().Trim() == "PCM.ALERTS")
                //{
                    ds = objRole.GetRecord(user);
                //}
                //else
                //{
                //    DataTable dt = new DataTable();
                //    dt.Columns.Add("status");
                //    dt.Columns.Add("msg");
                //    //dt.Columns["Token"].DefaultValue = tokenandexpire[0];
                //    DataRow row = dt.NewRow();
                //    row["status"] = "-1";
                //    dt.Rows.Add(row);
                //    DataRow row1 = dt.NewRow();
                //    row["msg"] = "User is not Authorized";
                //    dt.Rows.Add(row1);
                //    dt.TableName = "table";
                //    //if (!ds.Tables.Contains(dt.TableName))
                //    ds.Tables.Add(dt);
                //    // response = "User is not Authorized";
                //}

            }
            catch (Exception ex)
            {

            }
            return ds;
        }



        [HttpGet]
        [Route("api/UserMaster/GetAllRecordForDDL")]
        public DataSet GetAllRecordForDDL()
        {
            String Flag = "DropDown";
      
            DataTable dtinput;
            DataSet dsoutput;
            string UMEncryPass = "";

            dtinput = new DataTable();
            dsoutput = new DataSet();

            dtinput.Columns.Add("data");
            dtinput.Columns.Add("value");

            //dtinput.Rows.Add("p_Qflag", Flag);
            dtinput.Rows.Add("p_Auto_Id", "");
            dtinput.Rows.Add("p_User_Id", "");
            dtinput.Rows.Add("p_Group_Id", "");
            dtinput.Rows.Add("p_User_Name", "");
            dtinput.Rows.Add("p_Password", "");
            dtinput.Rows.Add("p_Email", "");
            dtinput.Rows.Add("p_Module_Id", "");
            dtinput.Rows.Add("p_fstlogin", "");
            dtinput.Rows.Add("p_Login_Status", "");
            dtinput.Rows.Add("p_Login_System", "");
            dtinput.Rows.Add("p_nooflogintry", "");
            dtinput.Rows.Add("p_Status", "");
            dtinput.Rows.Add("p_UserID", "");
            dtinput.Rows.Add("p_CreatedDate", "");
            dtinput.Rows.Add("p_ModifiedDate", "");
            dtinput.Rows.Add("p_ApprovedDate", "");
            dtinput.Rows.Add("p_Qflag", Flag);
            dtinput.Rows.Add("p_ReportGroupId", "");
            dtinput.Rows.Add("p_Dept_Id", "");
            dtinput.Rows.Add("p_UserRights", "");
            dtinput.Rows.Add("p_Module_Access_Id", "");
            dtinput.Rows.Add("p_Groupidcheck", "");
            dtinput.Rows.Add("p_Active", "");
            dtinput.Rows.Add("p_Dormant", ""); //Added By Neetu Sharma on 08April2024
                                               //Added by saurabh Deshmukh on 17OCt2024 start
            dtinput.Rows.Add("p_DEPARTMENT_CODE", null);
            dtinput.Rows.Add("p_DEPARTMENT_NAME", null);
            dtinput.Rows.Add("p_BRANCH_CODE", null);
            dtinput.Rows.Add("P_BRANCH_NAME", null);
            //Added by saurabh Deshmukh on 17OCt2024 End

            dsoutput = cf.callProcedure("USP_DDP_USERMASTER_IUDS", dtinput, 1);
            return dsoutput;
        }



      


       





        [HttpPost]
        [Route("api/UserMaster/UserMaster_IUDS")]

        public DataSet UserMaster_IUDS(User_Master obj)
        {
            String errmsg = "";
            DataSet ds;
            DataTable dtinput;
            DataSet dsoutput;
            string UMEncryPass = "";

            dtinput = new DataTable();
            dsoutput = new DataSet();



            dtinput.Columns.Add("data");
            dtinput.Columns.Add("value");

            //dtinput.Rows.Add("p_Qflag", fnGetDecryptedString(obj.ProcessName);
            //dtinput.Rows.Add("p_Auto_Id", fnGetDecryptedString(obj.Auto_Id);
            //dtinput.Rows.Add("p_User_Id", fnGetDecryptedString(obj.UserId);
            //dtinput.Rows.Add("p_User_Name", fnGetDecryptedString(obj.User_Name);
            //dtinput.Rows.Add("p_Password", UMEncryPass);
            //dtinput.Rows.Add("p_Group_Id", fnGetDecryptedString(obj.UserRole);
            //dtinput.Rows.Add("p_Email", fnGetDecryptedString(obj.Email);

            dtinput.Rows.Add("p_Auto_Id", fnGetDecryptedString(obj.Auto_Id));
            dtinput.Rows.Add("p_User_Id", fnGetDecryptedString(obj.UserId));
            dtinput.Rows.Add("p_Group_Id", fnGetDecryptedString(obj.UserRole));
            dtinput.Rows.Add("p_User_Name", fnGetDecryptedString(obj.User_Name));
            dtinput.Rows.Add("p_Password", UMEncryPass);
            dtinput.Rows.Add("p_Email", fnGetDecryptedString(obj.Email));
            dtinput.Rows.Add("p_Module_Id", "");
            dtinput.Rows.Add("p_fstlogin", "");
            dtinput.Rows.Add("p_Login_Status", "");
            dtinput.Rows.Add("p_Login_System", "");
            dtinput.Rows.Add("p_nooflogintry", "");
            dtinput.Rows.Add("p_Status", "");
            dtinput.Rows.Add("p_UserID", "");
            dtinput.Rows.Add("p_CreatedDate", "");
            dtinput.Rows.Add("p_ModifiedDate", "");
            dtinput.Rows.Add("p_ApprovedDate", "");
            dtinput.Rows.Add("p_Qflag", fnGetDecryptedString(obj.ProcessName));
            dtinput.Rows.Add("p_ReportGroupId", "");
            dtinput.Rows.Add("p_Dept_Id", "");
            dtinput.Rows.Add("p_UserRights", "");
            dtinput.Rows.Add("p_Module_Access_Id", "");
            dtinput.Rows.Add("p_Groupidcheck", fnGetDecryptedString( obj.groupidcheck));
          
            dtinput.Rows.Add("p_Active", fnGetDecryptedString(obj.Active));
            dtinput.Rows.Add("p_Dormant", fnGetDecryptedString(obj.Dormant));  //Added By Neetu on 08April2024

            //Added by saurabh Deshmukh on 17OCt2024 start
            dtinput.Rows.Add("p_DEPARTMENT_CODE", "");
            dtinput.Rows.Add("p_DEPARTMENT_NAME","");
            dtinput.Rows.Add("p_BRANCH_CODE", "");
            dtinput.Rows.Add("P_BRANCH_NAME","");
            //Added by saurabh Deshmukh on 17OCt2024 End
            dsoutput = cf.callProcedure("USP_DDP_USERMASTER_IUDS", dtinput, 1);

            return dsoutput;
        }


        //public string fnGetDecryptedString(string str)
        //{
        //    if (str == null)
        //    {
        //        return str;
        //    }
        //    else
        //    {
        //        var keybytes = Encoding.UTF8.GetBytes("8080808080808080");
        //        var iv = Encoding.UTF8.GetBytes("8080808080808080");

        //        byte[] str1 = Convert.FromBase64String(str);
        //        str = AESEncrytDecry.Decrypt(str1, keybytes, iv);
        //        return str;
        //    }


        //}

        public string fnGetEncryptedString21(string str)
        {

            using (AesManaged aes = new AesManaged())
            {
                var keybytes = Encoding.UTF8.GetBytes("8080808080808080");
                var iv = Encoding.UTF8.GetBytes("8080808080808080");

                byte[] encrypted = AESEncrytDecry.Encrypt("MANUAL", keybytes, iv);

                string converted = Convert.ToBase64String(encrypted);

                return converted;




            }

        }
        public string fnGetDecryptedString21(string str)
        {
            //17 10 2019 start
            if (str == null)
            {
                return str;
            }
            else
            {
                var keybytes = Encoding.UTF8.GetBytes("8080808080808080");
                var iv = Encoding.UTF8.GetBytes("8080808080808080");


                str = AESEncrytDecry.DecryptStringAES(str);
                return str;
            }

        }

        public string fnGetDecryptedString(string str)
        {
            //17 10 2019 start
            if (str == null)
            {
                return str;
            }
            else
            {
                var keybytes = Encoding.UTF8.GetBytes("8080808080808080");
                var iv = Encoding.UTF8.GetBytes("8080808080808080");

             
                str = AESEncrytDecry.DecryptStringAES(str);
                return str;
            }

        }

        //Added By Aniket Bhoite 13102023
        [Route("api/UserMaster/UnlockUser")]
        [HttpPost]
        public DataSet UnlockUser(User_Master obj)
        {
#pragma warning disable CS0219 // The variable 'errmsg' is assigned but its value is never used
            String errmsg = "";
#pragma warning restore CS0219 // The variable 'errmsg' is assigned but its value is never used
#pragma warning disable CS0168 // The variable 'ds' is declared but never used
            DataSet ds;
#pragma warning restore CS0168 // The variable 'ds' is declared but never used
            DataTable dtinput;
            DataSet dsoutput;
            string UMEncryPass = "";

            dtinput = new DataTable();
            dsoutput = new DataSet();

            dtinput.Columns.Add("data");
            dtinput.Columns.Add("value");



            dtinput.Rows.Add("p_Auto_Id", fnGetDecryptedString(obj.Auto_Id));
            dtinput.Rows.Add("p_User_Id", fnGetDecryptedString(obj.UserId));
            dtinput.Rows.Add("p_Group_Id", fnGetDecryptedString(obj.UserRole));
            dtinput.Rows.Add("p_User_Name", fnGetDecryptedString(obj.User_Name));
            dtinput.Rows.Add("p_Password", UMEncryPass);
            dtinput.Rows.Add("p_Email", fnGetDecryptedString(obj.Email));
            dtinput.Rows.Add("p_Module_Id", "");
            dtinput.Rows.Add("p_fstlogin", "");
            dtinput.Rows.Add("p_Login_Status", "");
            dtinput.Rows.Add("p_Login_System", "");
            dtinput.Rows.Add("p_nooflogintry", "");
            dtinput.Rows.Add("p_Status", "");
            dtinput.Rows.Add("p_UserID", "");
            dtinput.Rows.Add("p_CreatedDate", "");
            dtinput.Rows.Add("p_ModifiedDate", "");
            dtinput.Rows.Add("p_ApprovedDate", "");
            dtinput.Rows.Add("p_Qflag", fnGetDecryptedString(obj.ProcessName));
            dtinput.Rows.Add("p_ReportGroupId", "");
            dtinput.Rows.Add("p_Dept_Id", "");
            dtinput.Rows.Add("p_UserRights", "");
            dtinput.Rows.Add("p_Module_Access_Id", "");
            dtinput.Rows.Add("p_groupidcheck", "");
            dtinput.Rows.Add("p_isactive", "");
            dtinput.Rows.Add("p_Dormant", fnGetDecryptedString(obj.Dormant));//akhilesh 09APR24
                                                                             //Added by saurabh Deshmukh on 17OCt2024 start
            dtinput.Rows.Add("p_DEPARTMENT_CODE", "");
            dtinput.Rows.Add("p_DEPARTMENT_NAME", "");
            dtinput.Rows.Add("p_BRANCH_CODE", "");
            dtinput.Rows.Add("P_BRANCH_NAME", "");
            //Added by saurabh Deshmukh on 17OCt2024 End
            dsoutput = cf.callProcedure("USP_DDP_USERMASTER_IUDS", dtinput, 1);
            
            return dsoutput;
        }
        //Added By Aniket Bhoite 13102023

    }
}
