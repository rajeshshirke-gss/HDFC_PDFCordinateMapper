﻿using BAL;
using DAL;
using DAL.CommonClasses;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Http;

namespace Webapi.Controllers
{
    public class welcomeController : ApiController
    {
        DataSet dsoutput;
        DataTable dtinput;
        CommonFunction cf = new CommonFunction();
        //[Authorize]
        //[UseSSL]

        //[Route("api/welcome/GetData")]
        //[HttpPost]
        ////public DataSet GetData(string userId)
        //public DataSet GetData(string UserId)
        //{

        //    DataSet ds = new DataSet();
        //    Welcome objRole = new Welcome();
        //    try
        //    {
        //        ds = objRole.GetRecord(UserId);
        //    }
        //    catch (Exception ex)
        //    {


        //    }
        //    return ds;
        //}



        //[Authorize]
        [UseSSL]
        [Route("api/welcome/GetData")]
        [HttpPost]
        public IHttpActionResult GetData([FromBody]JObject json)
        {
            try
            {
                // USER VALIDATION START 12 09 2024
                // Get Authorization header
                var authorizationHeader = Request.Headers.Authorization?.ToString();                //Added  by Ketan Jadhav Dated 12-Sept-2024
                if (cf.OnAuthorizationCheck(authorizationHeader) == true)
                {
                   // obj.UserId = cf.checkuserid(authorizationHeader) != null ? cf.checkuserid(authorizationHeader) : obj.UserId;
                }
                else
                {
                    return null;
                }
                // USER VALIDATION END 12 09 2024

                Welcome request = JsonConvert.DeserializeObject<Welcome>(json.ToString());
                string UserId = fnGetDecryptedString(request.UserId);
                Welcome objWelcome = new Welcome();
                var Modulelist = objWelcome.GetRecord(UserId);
                if (Modulelist == null)
                {
                    return NotFound();
                }
                return Ok(Modulelist);
            }
            catch (Exception ex)
            {
                return Ok(ex.ToString());
            }
            // return "test123";
        }

        public string fnGetDecryptedString(string str)
        {
            if (str == null)
            {
                return str;
            }
            else
            {
                var keybytes = Encoding.UTF8.GetBytes("8080808080808080");
                var iv = Encoding.UTF8.GetBytes("8080808080808080");

                byte[] str1 = Convert.FromBase64String(str);
                str = AESEncrytDecry.Decrypt(str1, keybytes, iv);
                return str;
            }

        }
    }
}